-- MySQL dump 10.13  Distrib 5.6.33, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: yii2-starter-kit
-- ------------------------------------------------------
-- Server version	5.6.33-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `thumbnail_base_url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail_path` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `published_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_author` (`created_by`),
  KEY `fk_article_updater` (`updated_by`),
  KEY `fk_article_category` (`category_id`),
  CONSTRAINT `fk_article_author` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_article_category` FOREIGN KEY (`category_id`) REFERENCES `article_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_article_updater` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_attachment`
--

DROP TABLE IF EXISTS `article_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `base_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_attachment_article` (`article_id`),
  CONSTRAINT `fk_article_attachment_article` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_attachment`
--

LOCK TABLES `article_attachment` WRITE;
/*!40000 ALTER TABLE `article_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `article_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_category`
--

DROP TABLE IF EXISTS `article_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_category_section` (`parent_id`),
  CONSTRAINT `fk_article_category_section` FOREIGN KEY (`parent_id`) REFERENCES `article_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_category`
--

LOCK TABLES `article_category` WRITE;
/*!40000 ALTER TABLE `article_category` DISABLE KEYS */;
INSERT INTO `article_category` VALUES (1,'news','News',NULL,NULL,1,1498388456,NULL);
/*!40000 ALTER TABLE `article_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '2',
  `description` text COLLATE utf8_unicode_ci,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'Житомирський міськрайонний відділ',1,'',1498563351,1498653139,1,2),(2,'Андрушівський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(3,'Бердичівський районний відділ',2,NULL,1498563351,1498563351,1,1),(4,'Коростенський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(5,'Коростишівський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(6,'Малинський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(7,'Новоград-Волинський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(8,'Овруцький міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(9,'Олевський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1),(10,'Романівський міжрайонний відділ',2,NULL,1498563351,1498563351,1,1);
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` VALUES (1,'Житомир місто ',1,1498563351,1498643514,1,2),(2,'Житомирський район',1,1498563351,1498563351,1,1),(3,'Олевський район',1,1498563351,1498563351,1,1),(4,'Лугинський район',1,1498563351,1498563351,1,1),(5,'Овруцький район',1,1498563351,1498563351,1,1),(6,'Новоград-Волинський місто',1,1498563351,1498563351,1,1),(7,'Новоград-Волинський район',1,1498563351,1498563351,1,1),(8,'Народицький район',1,1498563351,1498563351,1,1),(9,'Ємільчинський район',1,1498563351,1498563351,1,1),(10,'Володарсько - Волинський район',1,1498563351,1498563351,1,1),(11,'Коростень місто',1,1498563351,1498563351,1,1),(12,'Коростенський район',1,1498563351,1498563351,1,1),(13,'Малин місто',1,1498563351,1498563351,1,1),(14,'Малинський район',1,1498563351,1498563351,1,1),(15,'Радомишльський район',1,1498563351,1498563351,1,1),(16,'Червоноармійський район',1,1498563351,1498563351,1,1),(17,'Баранівський район',1,1498563351,1498563351,1,1),(18,'Черняхівський район',1,1498563351,1498563351,1,1),(19,'Коростишівський район',1,1498563351,1498563351,1,1),(20,'Брусилівський район',1,1498563351,1498563351,1,1),(21,'Романівський район',1,1498563351,1498563351,1,1),(22,'Любарський район',1,1498563351,1498563351,1,1),(23,'Бердичів місто',1,1498563351,1498563351,1,1),(24,'Бердичівський район',1,1498563351,1498563351,1,1),(25,'Чуднівський район',1,1498563351,1498563351,1,1),(26,'Андрушівський район',1,1498563351,1498563351,1,1),(27,'Попільнянський район',1,1498563351,1498563351,1,1),(28,'Ружинський район',1,1498563351,1498563351,1,1);
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `division` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `type_div` int(11) NOT NULL,
  `type_lab` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `division`
--

LOCK TABLES `division` WRITE;
/*!40000 ALTER TABLE `division` DISABLE KEYS */;
INSERT INTO `division` VALUES (1,'Відділ №1',1,2,1,1498664216,1498682531,1,1),(2,'БАК лаб',3,3,2,1498682591,1498682602,1,1);
/*!40000 ALTER TABLE `division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage_item`
--

DROP TABLE IF EXISTS `file_storage_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_storage_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component` varchar(255) NOT NULL,
  `base_url` varchar(1024) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `upload_ip` varchar(15) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage_item`
--

LOCK TABLES `file_storage_item` WRITE;
/*!40000 ALTER TABLE `file_storage_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_storage_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i18n_message`
--

DROP TABLE IF EXISTS `i18n_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `i18n_message` (
  `id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `translation` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`,`language`),
  CONSTRAINT `fk_i18n_message_source_message` FOREIGN KEY (`id`) REFERENCES `i18n_source_message` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i18n_message`
--

LOCK TABLES `i18n_message` WRITE;
/*!40000 ALTER TABLE `i18n_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `i18n_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i18n_source_message`
--

DROP TABLE IF EXISTS `i18n_source_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `i18n_source_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i18n_source_message`
--

LOCK TABLES `i18n_source_message` WRITE;
/*!40000 ALTER TABLE `i18n_source_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `i18n_source_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jreg`
--

DROP TABLE IF EXISTS `jreg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jreg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_lab` int(11) NOT NULL,
  `type_direction` int(11) NOT NULL,
  `type_when_dir_1` int(11) NOT NULL,
  `type_when_dir_2` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jreg`
--

LOCK TABLES `jreg` WRITE;
/*!40000 ALTER TABLE `jreg` DISABLE KEYS */;
/*!40000 ALTER TABLE `jreg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key_storage_item`
--

DROP TABLE IF EXISTS `key_storage_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key_storage_item` (
  `key` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `updated_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `idx_key_storage_item_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_storage_item`
--

LOCK TABLES `key_storage_item` WRITE;
/*!40000 ALTER TABLE `key_storage_item` DISABLE KEYS */;
INSERT INTO `key_storage_item` VALUES ('backend.layout-boxed','0',NULL,NULL,NULL),('backend.layout-collapsed-sidebar','0',NULL,NULL,NULL),('backend.layout-fixed','0',NULL,NULL,NULL),('backend.theme-skin','skin-black','skin-blue, skin-black, skin-purple, skin-green, skin-red, skin-yellow',1498390313,NULL),('frontend.maintenance','disabled','Set it to \"true\" to turn on maintenance mode',NULL,NULL);
/*!40000 ALTER TABLE `key_storage_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS `material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_lab` int(11) NOT NULL,
  `type_direction` int(11) NOT NULL,
  `type_when_dir_1` int(11) NOT NULL,
  `type_when_dir_2` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material`
--

LOCK TABLES `material` WRITE;
/*!40000 ALTER TABLE `material` DISABLE KEYS */;
/*!40000 ALTER TABLE `material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission`
--

DROP TABLE IF EXISTS `mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_lab` int(11) NOT NULL,
  `type_direction` int(11) NOT NULL,
  `type_when_dir_1` int(11) NOT NULL,
  `type_when_dir_2` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission`
--

LOCK TABLES `mission` WRITE;
/*!40000 ALTER TABLE `mission` DISABLE KEYS */;
/*!40000 ALTER TABLE `mission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(2048) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

LOCK TABLES `page` WRITE;
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES (1,'about','About','Lorem ipsum dolor sit amet, consectetur adipiscing elit.',NULL,1,1498388456,1498388456);
/*!40000 ALTER TABLE `page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_assignment`
--

DROP TABLE IF EXISTS `rbac_auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `rbac_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_assignment`
--

LOCK TABLES `rbac_auth_assignment` WRITE;
/*!40000 ALTER TABLE `rbac_auth_assignment` DISABLE KEYS */;
INSERT INTO `rbac_auth_assignment` VALUES ('superadm','1',1498821612),('viewer','4',1498817170);
/*!40000 ALTER TABLE `rbac_auth_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_item`
--

DROP TABLE IF EXISTS `rbac_auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `rbac_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `rbac_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_item`
--

LOCK TABLES `rbac_auth_item` WRITE;
/*!40000 ALTER TABLE `rbac_auth_item` DISABLE KEYS */;
INSERT INTO `rbac_auth_item` VALUES ('loginToBackend',2,NULL,NULL,NULL,1498819911,1498819911),('orgadm',1,NULL,NULL,NULL,1498816415,1498816415),('orgopr',1,NULL,NULL,NULL,1498816415,1498816415),('superadm',1,NULL,NULL,NULL,1498816415,1498816415),('techadm',1,NULL,NULL,NULL,1498816415,1498816415),('techopr',1,NULL,NULL,NULL,1498816415,1498816415),('viewer',1,NULL,NULL,NULL,1498816415,1498816415);
/*!40000 ALTER TABLE `rbac_auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_item_child`
--

DROP TABLE IF EXISTS `rbac_auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `rbac_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rbac_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_item_child`
--

LOCK TABLES `rbac_auth_item_child` WRITE;
/*!40000 ALTER TABLE `rbac_auth_item_child` DISABLE KEYS */;
INSERT INTO `rbac_auth_item_child` VALUES ('viewer','loginToBackend'),('superadm','orgadm'),('superadm','orgopr'),('superadm','techadm'),('superadm','techopr'),('superadm','viewer');
/*!40000 ALTER TABLE `rbac_auth_item_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_rule`
--

DROP TABLE IF EXISTS `rbac_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_rule`
--

LOCK TABLES `rbac_auth_rule` WRITE;
/*!40000 ALTER TABLE `rbac_auth_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scenario`
--

DROP TABLE IF EXISTS `scenario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scenario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scenario`
--

LOCK TABLES `scenario` WRITE;
/*!40000 ALTER TABLE `scenario` DISABLE KEYS */;
/*!40000 ALTER TABLE `scenario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slog`
--

DROP TABLE IF EXISTS `slog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` int(11) NOT NULL,
  `tbl_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_intbl` int(11) NOT NULL,
  `data_befor` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_after` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slog`
--

LOCK TABLES `slog` WRITE;
/*!40000 ALTER TABLE `slog` DISABLE KEYS */;
INSERT INTO `slog` VALUES (8,1498601637,'district',1,'{\"Назва\":\"Житомир місто 456\"}','{\"Назва\":\"Житомир місто 555\"}'),(9,1498602160,'district',1,'{\"Назва\":\"Житомир місто 555\",\"Відділення\":3}','{\"Назва\":\"Житомир місто qwerty\",\"Відділення\":\"1\"}'),(10,1498643514,'district',1,'{\"Назва\":\"Житомир місто qwerty\",\"Змінено (ким)\":1}','{\"Назва\":\"Житомир місто \",\"Змінено (ким)\":2}'),(11,1498644057,'district',29,'{\"Назва\":\"null\",\"Відділення\":\"null\",\"Створено (коли)\":\"null\",\"Створено (ким)\":\"null\",\"Змінено (ким)\":\"null\",\"ID\":\"null\"}','{\"Назва\":\"qwerty\",\"Відділення\":\"10\",\"Створено (коли)\":1498644057,\"Створено (ким)\":2,\"Змінено (ким)\":2,\"ID\":29}'),(12,1498653139,'branch',1,'{\"Тип\":2,\"Змінено (ким)\":1}','{\"Тип\":\"1\",\"Змінено (ким)\":2}'),(13,1498664216,'division',1,'{\"Name\":\"null\",\"Branch ID\":\"null\",\"Type Div\":\"null\",\"Type Lab\":\"null\",\"Created At\":\"null\",\"Created By\":\"null\",\"Updated By\":\"null\",\"ID\":\"null\"}','{\"Name\":\"111\",\"Branch ID\":\"1\",\"Type Div\":\"1\",\"Type Lab\":\"1\",\"Created At\":1498664216,\"Created By\":1,\"Updated By\":1,\"ID\":1}'),(14,1498664287,'division',1,'{\"Name\":\"111\"}','{\"Name\":\"11122222\"}'),(15,1498664355,'division',1,'{\"Name\":\"11122222\"}','{\"Name\":\"159159191\"}'),(16,1498682531,'division',1,'{\"Назва\":\"159159191\",\"Тип підрозділу\":1}','{\"Назва\":\"Відділ №1\",\"Тип підрозділу\":\"2\"}'),(17,1498682591,'division',2,'{\"Назва\":\"null\",\"Відділення\":\"null\",\"Тип підрозділу\":\"null\",\"Тип лабораторії\":\"null\",\"Створено (коли)\":\"null\",\"Створено (ким)\":\"null\",\"Змінено (ким)\":\"null\",\"ID\":\"null\"}','{\"Назва\":\"БАК лаб\",\"Відділення\":\"1\",\"Тип підрозділу\":\"3\",\"Тип лабораторії\":\"2\",\"Створено (коли)\":1498682591,\"Створено (ким)\":1,\"Змінено (ким)\":1,\"ID\":2}'),(18,1498682602,'division',2,'{\"Відділення\":1}','{\"Відділення\":\"3\"}');
/*!40000 ALTER TABLE `slog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_db_migration`
--

DROP TABLE IF EXISTS `system_db_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_db_migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_db_migration`
--

LOCK TABLES `system_db_migration` WRITE;
/*!40000 ALTER TABLE `system_db_migration` DISABLE KEYS */;
INSERT INTO `system_db_migration` VALUES ('m000000_000000_base',1498388454),('m140703_123000_user',1498388454),('m140703_123055_log',1498388454),('m140703_123104_page',1498388454),('m140703_123803_article',1498388454),('m140703_123813_rbac',1498388454),('m140709_173306_widget_menu',1498388454),('m140709_173333_widget_text',1498388454),('m140712_123329_widget_carousel',1498388454),('m140805_084745_key_storage_item',1498388454),('m141012_101932_i18n_tables',1498388454),('m150318_213934_file_storage_item',1498388454),('m150414_195800_timeline_event',1498388454),('m150725_192740_seed_data',1498388456),('m150929_074021_article_attachment_order',1498388456),('m160203_095604_user_token',1498388456),('m170430_134932_create_branch_table',1498563351),('m170430_135235_create_district_table',1498563351),('m170430_153259_create_division_table',1498563351),('m170430_153328_create_workplace_table',1498563351),('m170430_153631_create_scenario_table',1498563351),('m170430_194839_create_forms_table',1498563351),('m170430_195001_create_jreg_table',1498563351),('m170430_201146_create_material_table',1498563351),('m170430_201516_create_mission_table',1498563351),('m170627_105050_create_slog_table',1498563351),('m170627_105839_fill_district_table',1498563351),('m170627_112353_fill_branch_table',1498563351);
/*!40000 ALTER TABLE `system_db_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_time` double DEFAULT NULL,
  `prefix` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_log_level` (`level`),
  KEY `idx_log_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
INSERT INTO `system_log` VALUES (132,1,'yii\\i18n\\PhpMessageSource::loadFallbackMessages',1498937749.7244,'[backend][/db-manager]','The message file for category \'dbManager\' does not exist: /var/www/vendor/beaten-sect0r/yii2-db-manager/src/messages/uk-UA/dbManager.php Fallback file does not exist as well: /var/www/vendor/beaten-sect0r/yii2-db-manager/src/messages/uk/dbManager.php'),(133,1,'yii\\i18n\\PhpMessageSource::loadFallbackMessages',1498937995.6154,'[backend][/db-manager]','The message file for category \'dbManager\' does not exist: /var/www/vendor/beaten-sect0r/yii2-db-manager/src/messages/uk-UA/dbManager.php Fallback file does not exist as well: /var/www/vendor/beaten-sect0r/yii2-db-manager/src/messages/uk/dbManager.php'),(134,1,'yii\\i18n\\PhpMessageSource::loadFallbackMessages',1498938018.0047,'[backend][/db-manager]','The message file for category \'dbManager\' does not exist: /var/www/vendor/beaten-sect0r/yii2-db-manager/src/messages/uk-UA/dbManager.php Fallback file does not exist as well: /var/www/vendor/beaten-sect0r/yii2-db-manager/src/messages/uk/dbManager.php'),(135,1,'yii\\i18n\\PhpMessageSource::loadFallbackMessages',1498938127.8852,'[backend][/db-manager]','The message file for category \'dbManager\' does not exist: /var/www/common/messages/uk-UA/dbManager.php Fallback file does not exist as well: /var/www/common/messages/uk/dbManager.php'),(136,1,'yii\\base\\InvalidConfigException',1498939271.8201,'[backend][/db-manager/default/index]','yii\\base\\InvalidConfigException: Object configuration must be an array containing a \"class\" element. in /var/www/vendor/yiisoft/yii2/BaseYii.php:352\nStack trace:\n#0 /var/www/vendor/yiisoft/yii2/i18n/I18N.php(176): yii\\BaseYii::createObject(Array)\n#1 /var/www/vendor/yiisoft/yii2/i18n/I18N.php(88): yii\\i18n\\I18N->getMessageSource(\'dbManager\')\n#2 /var/www/vendor/yiisoft/yii2/BaseYii.php(509): yii\\i18n\\I18N->translate(\'dbManager\', \'DB manager\', Array, \'uk-UA\')\n#3 /var/www/vendor/beaten-sect0r/yii2-db-manager/src/views/default/index.php(14): yii\\BaseYii::t(\'dbManager\', \'DB manager\')\n#4 /var/www/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/vendor...\')\n#5 /var/www/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'/var/www/vendor...\', Array)\n#6 /var/www/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'/var/www/vendor...\', Array, Object(bs\\dbManager\\controllers\\DefaultController))\n#7 /var/www/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(bs\\dbManager\\controllers\\DefaultController))\n#8 /var/www/vendor/beaten-sect0r/yii2-db-manager/src/controllers/DefaultController.php(70): yii\\base\\Controller->render(\'index\', Array)\n#9 [internal function]: bs\\dbManager\\controllers\\DefaultController->actionIndex()\n#10 /var/www/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#11 /var/www/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#12 /var/www/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#13 /var/www/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'db-manager/defa...\', Array)\n#14 /var/www/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#15 /var/www/backend/web/index.php(23): yii\\base\\Application->run()\n#16 {main}'),(137,1,'ReflectionException',1498939309.7682,'[backend][/db-manager/default/index]','ReflectionException: Class  does not exist in /var/www/vendor/yiisoft/yii2/di/Container.php:424\nStack trace:\n#0 /var/www/vendor/yiisoft/yii2/di/Container.php(424): ReflectionClass->__construct(\'\')\n#1 /var/www/vendor/yiisoft/yii2/di/Container.php(364): yii\\di\\Container->getDependencies(\'\')\n#2 /var/www/vendor/yiisoft/yii2/di/Container.php(156): yii\\di\\Container->build(\'\', Array, Array)\n#3 /var/www/vendor/yiisoft/yii2/BaseYii.php(348): yii\\di\\Container->get(\'\', Array, Array)\n#4 /var/www/vendor/yiisoft/yii2/i18n/I18N.php(176): yii\\BaseYii::createObject(Array)\n#5 /var/www/vendor/yiisoft/yii2/i18n/I18N.php(88): yii\\i18n\\I18N->getMessageSource(\'dbManager\')\n#6 /var/www/vendor/yiisoft/yii2/BaseYii.php(509): yii\\i18n\\I18N->translate(\'dbManager\', \'DB manager\', Array, \'uk-UA\')\n#7 /var/www/vendor/beaten-sect0r/yii2-db-manager/src/views/default/index.php(14): yii\\BaseYii::t(\'dbManager\', \'DB manager\')\n#8 /var/www/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/vendor...\')\n#9 /var/www/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'/var/www/vendor...\', Array)\n#10 /var/www/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'/var/www/vendor...\', Array, Object(bs\\dbManager\\controllers\\DefaultController))\n#11 /var/www/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(bs\\dbManager\\controllers\\DefaultController))\n#12 /var/www/vendor/beaten-sect0r/yii2-db-manager/src/controllers/DefaultController.php(70): yii\\base\\Controller->render(\'index\', Array)\n#13 [internal function]: bs\\dbManager\\controllers\\DefaultController->actionIndex()\n#14 /var/www/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#15 /var/www/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#16 /var/www/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#17 /var/www/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'db-manager/defa...\', Array)\n#18 /var/www/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#19 /var/www/backend/web/index.php(23): yii\\base\\Application->run()\n#20 {main}'),(138,1,'yii\\i18n\\PhpMessageSource::loadFallbackMessages',1498939334.5969,'[backend][/db-manager/default/index]','The message file for category \'dbManager\' does not exist: /var/www/backend/messages/uk-UA/dbManager.php Fallback file does not exist as well: /var/www/backend/messages/uk/dbManager.php'),(139,1,'Error',1498942288.3046,'[backend][/division/index]','Error: Class \'EnumColumn\' not found in /var/www/backend/views/division/index.php:36\nStack trace:\n#0 /var/www/vendor/yiisoft/yii2/base/View.php(330): require()\n#1 /var/www/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'/var/www/backen...\', Array)\n#2 /var/www/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'/var/www/backen...\', Array, Object(backend\\controllers\\DivisionController))\n#3 /var/www/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(backend\\controllers\\DivisionController))\n#4 /var/www/backend/controllers/DivisionController.php(46): yii\\base\\Controller->render(\'index\', Array)\n#5 [internal function]: backend\\controllers\\DivisionController->actionIndex()\n#6 /var/www/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#7 /var/www/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#8 /var/www/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#9 /var/www/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'division/index\', Array)\n#10 /var/www/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#11 /var/www/backend/web/index.php(23): yii\\base\\Application->run()\n#12 {main}');
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_rbac_migration`
--

DROP TABLE IF EXISTS `system_rbac_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_rbac_migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_rbac_migration`
--

LOCK TABLES `system_rbac_migration` WRITE;
/*!40000 ALTER TABLE `system_rbac_migration` DISABLE KEYS */;
INSERT INTO `system_rbac_migration` VALUES ('m000000_000000_base',1498388456),('m150625_214101_roles',1498816415),('m150625_215624_init_permissions',1498819911);
/*!40000 ALTER TABLE `system_rbac_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeline_event`
--

DROP TABLE IF EXISTS `timeline_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeline_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeline_event`
--

LOCK TABLES `timeline_event` WRITE;
/*!40000 ALTER TABLE `timeline_event` DISABLE KEYS */;
INSERT INTO `timeline_event` VALUES (1,'frontend','user','signup','{\"public_identity\":\"webmaster\",\"user_id\":1,\"created_at\":1498388454}',1498388454),(2,'frontend','user','signup','{\"public_identity\":\"manager\",\"user_id\":2,\"created_at\":1498388454}',1498388454),(3,'frontend','user','signup','{\"public_identity\":\"user\",\"user_id\":3,\"created_at\":1498388454}',1498388454),(4,'backend','division','change','{\"name\":\"qqqqqq\",\"branch_id\":\"1\"}',1498407337),(5,'backend','division','change','{\"name\":\"qqqqqq\",\"branch_id\":\"1\"}',1498407378),(6,'backend','division','change','{\"name\":\"qqqqqq\",\"branch_id\":\"1\"}',1498407418),(7,'backend','division','insert','{\"content\":\"new\",\"user_id\":1,\"created_at\":\"1\"}',1498407418),(8,'backend','user','signup','{\"public_identity\":\"utmp\",\"user_id\":4,\"created_at\":1498657367}',1498657367),(9,'backend','division','change','{\"name\":\"111\",\"branch_id\":\"1\"}',1498664216),(10,'backend','division','insert','{\"content\":\"new\",\"user_id\":1,\"created_at\":\"1\"}',1498664216),(11,'backend','division','change','{\"name\":\"11122222\",\"branch_id\":\"1\"}',1498664287),(12,'backend','division','change','{\"name\":\"159159191\",\"branch_id\":\"1\"}',1498664355);
/*!40000 ALTER TABLE `timeline_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oauth_client` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauth_client_user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '2',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `logged_at` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `level_access` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'webmaster','A0z03V1RSHwAHcksx0EA2qO2gK6D-XsV','EiDo_ycYyuVy5B55LS0JTf1rXcZ4EsczbiNUWYSz','$2y$13$FyRkZwMny/cxCfMD9qicI.OKmUZ/aR/d4fBnPlCiHZfzUF0q5F5lW',NULL,NULL,'webmaster@example.com',2,1498388455,1498821612,1498937745,1,1,1),(2,'manager','0E1zJPKdsWhk5b_Mp1X3E6Fn6W0JB4wt','Z0-x42SFGahBO1jwNu2VZQIQUTiWU3etKQHkAsFG','$2y$13$Hgr6PjDvINzgXIupAHNjvu4Rf3lNC2Nd2iuzuTL.X8WLqChQOnvmW',NULL,NULL,'manager@example.com',2,1498388455,1498388455,1498650993,1,1,1),(3,'user','Fe1opj_-FSCzQVltC5kDxmHYbEMH7npq','kSaVBdc4E53nMx5mE-HTVS0luyJeQg0pJj5Qo9EK','$2y$13$.um8I4NfkPGCNJm52kkWf.HctyjSCKkSfdOKMmhA1z6zX.UlFm2mG',NULL,NULL,'user@example.com',2,1498388456,1498388456,NULL,1,1,1),(4,'utmp','ZIwLEm86ucMB4nACaWkcFdR2FUXEKzoF','UmDePPy0vtQDwsp4Bsb6wZhkTho1ZjwdJyiWYqcG','$2y$13$IjFbj9ywzf929ueFqmMs2.eyS2qNKEPSh6kFkarb7ZxJR/dOhwjxe',NULL,NULL,'',2,1498657367,1498817170,1498817189,3,2,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middlename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_base_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `gender` smallint(1) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (1,'John','','Doe',NULL,NULL,'uk-UA',2),(2,'','','',NULL,NULL,'uk-UA',2),(3,NULL,NULL,NULL,NULL,NULL,'en-US',NULL),(4,'tmp','','',NULL,NULL,'uk-UA',1);
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_token`
--

DROP TABLE IF EXISTS `user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `expire_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_token`
--

LOCK TABLES `user_token` WRITE;
/*!40000 ALTER TABLE `user_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_carousel`
--

DROP TABLE IF EXISTS `widget_carousel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_carousel`
--

LOCK TABLES `widget_carousel` WRITE;
/*!40000 ALTER TABLE `widget_carousel` DISABLE KEYS */;
INSERT INTO `widget_carousel` VALUES (1,'index',1);
/*!40000 ALTER TABLE `widget_carousel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_carousel_item`
--

DROP TABLE IF EXISTS `widget_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_carousel_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carousel_id` int(11) NOT NULL,
  `base_url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `caption` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `order` int(11) DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_item_carousel` (`carousel_id`),
  CONSTRAINT `fk_item_carousel` FOREIGN KEY (`carousel_id`) REFERENCES `widget_carousel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_carousel_item`
--

LOCK TABLES `widget_carousel_item` WRITE;
/*!40000 ALTER TABLE `widget_carousel_item` DISABLE KEYS */;
INSERT INTO `widget_carousel_item` VALUES (1,1,'http://yii2-starter-kit.dev','img/yii2-starter-kit.gif','image/gif','/',NULL,1,0,NULL,NULL);
/*!40000 ALTER TABLE `widget_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_menu`
--

DROP TABLE IF EXISTS `widget_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `items` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_menu`
--

LOCK TABLES `widget_menu` WRITE;
/*!40000 ALTER TABLE `widget_menu` DISABLE KEYS */;
INSERT INTO `widget_menu` VALUES (1,'frontend-index','Frontend index menu','[\n    {\n        \"label\": \"Get started with Yii2\",\n        \"url\": \"http://www.yiiframework.com\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-success\\\">{label}</a>\"\n    },\n    {\n        \"label\": \"Yii2 Starter Kit on GitHub\",\n        \"url\": \"https://github.com/trntv/yii2-starter-kit\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-primary\\\">{label}</a>\"\n    },\n    {\n        \"label\": \"Find a bug?\",\n        \"url\": \"https://github.com/trntv/yii2-starter-kit/issues\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-danger\\\">{label}</a>\"\n    }\n]',1);
/*!40000 ALTER TABLE `widget_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_text`
--

DROP TABLE IF EXISTS `widget_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_widget_text_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_text`
--

LOCK TABLES `widget_text` WRITE;
/*!40000 ALTER TABLE `widget_text` DISABLE KEYS */;
INSERT INTO `widget_text` VALUES (1,'backend_welcome','Welcome to backend','<p>Welcome to Yii2 Starter Kit Dashboard</p>',1,1498388456,1498388456),(2,'ads-example','Google Ads Example Block','<div class=\"lead\">\n                <script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>\n                <ins class=\"adsbygoogle\"\n                     style=\"display:block\"\n                     data-ad-client=\"ca-pub-9505937224921657\"\n                     data-ad-slot=\"2264361777\"\n                     data-ad-format=\"auto\"></ins>\n                <script>\n                (adsbygoogle = window.adsbygoogle || []).push({});\n                </script>\n            </div>',0,1498388456,1498388456);
/*!40000 ALTER TABLE `widget_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workplace`
--

DROP TABLE IF EXISTS `workplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workplace` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workplace`
--

LOCK TABLES `workplace` WRITE;
/*!40000 ALTER TABLE `workplace` DISABLE KEYS */;
/*!40000 ALTER TABLE `workplace` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-01 21:19:43
